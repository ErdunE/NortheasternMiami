# German Traffic Sign Recognition Benchmark (GTSRB)
## AI-Powered Traffic Sign Classification for Autonomous Driving

### Project Overview

This project demonstrates the application of AI techniques to the real-world problem of traffic sign recognition using the German Traffic Sign Recognition Benchmark (GTSRB) dataset. The project showcases comprehensive deep learning approaches using **PyTorch** for classifying traffic signs, which is a critical component of autonomous driving systems and driver assistance technologies.


### Project Objectives

1. **Data Analysis**: Explore and understand the GTSRB dataset structure
2. **Preprocessing**: Implement data cleaning and augmentation techniques
3. **Model Development**: Build and train deep learning models using PyTorch
4. **Evaluation**: Assess model performance using appropriate metrics
5. **Real-world Application**: Demonstrate practical implementation for traffic sign recognition

### Technical Approach

#### Data Preprocessing
- Image normalization and resizing
- Data augmentation (rotation, shift, zoom, brightness adjustment)
- Train/validation/test split with stratification
- PyTorch Dataset and DataLoader implementation

#### Model Architectures
1. **Custom CNN**: A deep convolutional neural network with:
   - Multiple convolutional blocks with batch normalization
   - Dropout layers for regularization
   - Dense layers for classification

2. **Transfer Learning**: Using ResNet18 pre-trained on ImageNet:
   - Frozen base model for feature extraction
   - Custom classification head
   - Fine-tuning capabilities

#### Training Strategy
- Early stopping to prevent overfitting
- Learning rate scheduling with ReduceLROnPlateau
- Data augmentation for improved generalization
- Comprehensive evaluation metrics
- GPU acceleration support

### Installation and Setup

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd GTSRB-Traffic-Sign-Recognition
   ```

2. **Run the Jupyter notebook**:
   ```bash
   jupyter notebook GTSRB_Traffic_Sign_Recognition.ipynb
   ```

### Dataset

The project uses the GTSRB (German Traffic Sign Recognition Benchmark) dataset, which includes:
- 43 different traffic sign classes
- Over 50,000 images
- Various lighting conditions and angles
- Real-world traffic sign images from German roads

The dataset is automatically downloaded using KaggleHub when running the notebook.

### Key Features

#### Comprehensive Analysis
- Detailed data exploration and visualization
- Class distribution analysis
- Image quality assessment

#### Advanced AI Techniques
- Custom CNN architecture design using PyTorch
- Transfer learning implementation with ResNet18
- Data augmentation strategies
- Model comparison and evaluation

#### Real-world Application
- Traffic sign prediction function
- Model deployment considerations
- Performance analysis for real-time applications
- Cross-platform compatibility (CPU/GPU)

### Results and Performance

### Model Evaluation

Comprehensive evaluation using:
- Accuracy metrics
- Classification reports
- Confusion matrices
- Training history analysis
- Model comparison plots
- Deployment analysis



### Files Structure

```
GTSRB-Traffic-Sign-Recognition/
├── GTSRB_Traffic_Sign_Recognition.ipynb      # Main PyTorch notebook
├── README.md                                 # Project documentation
```

### Usage

1. Open the Jupyter notebook
2. Run all cells sequentially
3. The notebook will:
   - Download the GTSRB dataset
   - Perform data analysis and preprocessing
   - Train multiple PyTorch models
   - Evaluate and compare performance

### Requirements

- Python 3.8+
- PyTorch 1.12+
- CUDA-compatible GPU (optional, for faster training)
- 8GB+ RAM
- 5GB+ free disk space

### Hardware Support

The implementation automatically detects and utilizes available hardware:
- **CPU**: Full functionality with optimized performance
- **GPU**: Automatic CUDA acceleration for faster training



