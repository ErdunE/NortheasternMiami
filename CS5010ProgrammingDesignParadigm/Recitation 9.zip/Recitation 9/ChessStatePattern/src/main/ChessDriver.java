package main;

/**
 * Main class to start the chess game.
 */
public class ChessDriver {
	public static void main(String[] args) {
		ChessGame game = new ChessGame();
		game.start();
	}
}