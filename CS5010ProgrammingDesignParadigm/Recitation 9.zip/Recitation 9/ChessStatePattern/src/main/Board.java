package main;

import pieces.*;
import states.State;

/**
 * Represents the chess board, containing pieces and their locations.
 */
public class Board {
	private Piece[][] board;

	public Board() {
		this.board = new Piece[8][8];
		initializeBoard();
	}

	/**
	 * Initializes the board with the standard setup of pieces.
	 */
	private void initializeBoard() {
		// Place Rooks, Knights, Bishops, King, Queen, and Pawns for both players
		board[0][0] = new Rook("black");
		board[0][7] = new Rook("black");
		board[7][0] = new Rook("white");
		board[7][7] = new Rook("white");

		board[0][4] = new King("black");
		board[7][4] = new King("white");

		// Initialize other pieces similarly
	}

	/**
	 * Gets the piece at a specific location.
	 * @param row Row index
	 * @param col Column index
	 * @return Piece at location
	 */
	public Piece getPiece(int row, int col) {
		return board[row][col];
	}

	/**
	 * Sets a piece at a specific location.
	 * @param row Row index
	 * @param col Column index
	 * @param piece Piece to place
	 */
	public void setPiece(int row, int col, Piece piece) {
		board[row][col] = piece;
	}

	/**
	 * Checks if a move is valid according to the piece's move rules.
	 * @return true if the move is valid, false otherwise
	 */
	public boolean isValidMove(int startX, int startY, int endX, int endY) {
		Piece piece = getPiece(startX, startY);
		if (piece == null) return false;
		return piece.isValidMove(startX, startY, endX, endY, this);
	}
}