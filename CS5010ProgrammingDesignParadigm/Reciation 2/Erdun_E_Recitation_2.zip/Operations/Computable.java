package Operations;
/**
 *
 * @author Erdun E
 * @version 9/13/2024
 *
 * computable interface, two integer attributes and a method that returns an integer and take the two integer attributes as parameters
 *
 */
public interface Computable {
    public int compute(int a, int b);
}
