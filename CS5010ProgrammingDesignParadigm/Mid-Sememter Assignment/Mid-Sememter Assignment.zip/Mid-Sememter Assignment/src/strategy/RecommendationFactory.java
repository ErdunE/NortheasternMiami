package strategy;

// Planed to complete for final project
// Factory class to dynamically create strategies

public class RecommendationFactory {
}
