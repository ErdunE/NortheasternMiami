package model;

// Planed to complete for final project
// Simple model class representing a movie
// Will evolve to include more details (e.g., year, director).

public class Movie {
}
