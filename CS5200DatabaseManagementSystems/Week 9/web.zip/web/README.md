# Example Chinook Web Apps

## PHP Version

1. Copy `php` folder into `XAMPP/htdocs`
2. In XAMPP, run `MySQL` and `Apache` servers
3. In a browser, go to `http://localhost/php/`

## API Versions

1. In XAMPP, run `MySQL` server
2. Run the API (see below for Python/Node instructions)
3. In the `api` folder, start a local HTTP server using Python: `python -m http.server`
4. In a browser, go to `http://localhost:8000/ajax.html`

### Python

1. If needed, install via `pip install`: `pymysql` and `flask`
2. Run: `python chinook.py`

### Node

1. If needed, install via `npm install`: `mysql` and `express`
2. Run: `node chinook.js`
