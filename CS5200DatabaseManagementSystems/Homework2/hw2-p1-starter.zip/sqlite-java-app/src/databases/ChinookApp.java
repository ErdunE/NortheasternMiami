package databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.sqlite.SQLiteConfig;

/**
 * Command-line application for a set of queries
 * on the Chinook database
 * 
 * TODO: YOUR NAME HERE
 * 
 * @author derbinsky
 */
public class ChinookApp {
	
	/**
	 * Allowed queries
	 */
	private enum QueryType {
		CUSTOMER_BY_COUNTRY(
			"Count customers in country",
			true
		),
		
		ALL_EMPLOYEES(
			"List all employees (sorted by employee id)",
			false
		),
		
		CUSTOMERS_BY_EMPLOYEE_ID(
			"Count customers supported by employee id",
			true
		),
		
		ALL_CUSTOMERS(
			"List all customers (sorted by customer id)",
			false
		),
		
		INVOICES_BY_CUSTOMER_ID(
			"List all invoices (sorted by invoice id, each line by invoice line id) for customer id",
			true
		);
		
		/**
		 * Query description
		 */
		public final String desc;
		
		/**
		 * Whether the query requires
		 * a parameter value
		 */
		public final boolean needsParam;
		
		private QueryType(String desc, boolean needsParam) {
			this.desc = desc;
			this.needsParam = needsParam;
		}
		
		@Override
		public String toString() {
			final String fmt;
			if (needsParam) {
				fmt = "%s [parameter value]";
			} else {
				fmt = "%s";
			}
			
			return String.format(fmt, desc);
		}
	}
	
	/**
	 * Query and associated parameter 
	 * value (which is null if not appropriate)
	 * 
	 * @author derbinsky
	 */
	private static class QueryData {
		public final QueryType queryType;
		public final String queryParam;
		
		public QueryData(QueryType qn, String qp) {
			queryType = qn;
			queryParam = qp;
		}
		
		@Override
		public String toString() {
			final String formatString;
			if (queryParam == null) {
				formatString = "%s";
			} else {
				formatString = "%s (%s)";
			}
			
			return String.format(formatString, queryType, queryParam);
		}
	}
	
	/**
	 * Read-Only configuration
	 */
	private static final SQLiteConfig roConfig;
	static {
		roConfig = new SQLiteConfig();
		roConfig.setReadOnly(true);
	}
	
	/**
	 * Usage statement
	 * 
	 * @return null (to make other code easier)
	 */
	private static QueryData usage() {
		System.out.printf(
			"Usage: java %s <path to Chinook database> <query #> [parameter value]%n%n", 
			ChinookApp.class.getCanonicalName()
		);
		
		for (QueryType qt : QueryType.values()) {
			System.out.printf(
				"%d) %s%n",
				qt.ordinal() + 1,
				qt
			);
		}
		System.out.println();
		
		return null;
	}
	
	/**
	 * Prefix JDBC info to SQLite database path
	 * 
	 * @param path path to database
	 * @return JDBC connection string
	 */
	private static String sqliteConnection(String path) {
		return String.format("jdbc:sqlite:%s", path);
	}
	
	/**
	 * Validates SQLite connection to supplied database path
	 * 
	 * @param path path to database
	 * @return true if can connect to SQLite database
	 * @throws ClassNotFoundException cannot find JDBC driver
	 */
	private static boolean validateSQLite(String path) throws ClassNotFoundException {
		// attempt connecting to the database
		Class.forName( "org.sqlite.JDBC" );
		try (final Connection connection = DriverManager.getConnection(sqliteConnection(path), roConfig.toProperties())) {
			// means connection was successful
			final String testSQL = "SELECT COUNT(*) AS ct FROM artist WHERE Name=?";
			final String testParam = "Brandi Carlile";
			final int testExpected = 0;
			
			try (final PreparedStatement stmt = connection.prepareStatement(testSQL)) {
				stmt.setString(1, testParam);
				
				try (final ResultSet res = stmt.executeQuery()) {
					final int ct = res.getInt("ct");
					
					if (ct != testExpected) {
						System.out.println("Invalid databse contents");
					}
					
					return (ct == testExpected);
				}
			}
		} catch (SQLException e) {
			System.out.println("Invalid database");
			return false;
		}
	}
	
	/**
	 * Validates command-line arguments
	 * 
	 * @param args command-line arguments
	 * @return query data, or null if invalid
	 * @throws ClassNotFoundException cannot find JDBC driver
	 */
	private static QueryData validateInputs(String[] args) throws ClassNotFoundException {
		// must have at least two arguments
		if (args.length < 2) {
			return usage();
		}
		
		// must be able to connect to the database
		if (!validateSQLite(args[0])) {
			return usage();
		}
		
		// attempt converting first supplied parameter
		// to a number
		final int queryNum;
		try {
			queryNum = Integer.parseInt(args[1]) - 1;
		} catch (NumberFormatException e) {
			return usage();
		}
		
		// make sure second argument is a valid query number
		// and third is appropriate to query
		if ((queryNum >= 0) && (queryNum < QueryType.values().length)) {
			final QueryType qt = QueryType.values()[queryNum];

			// parameter value in slot 3
			if (qt.needsParam && (args.length != 3)) {
				return usage();
			}
			
			// no parameter value
			if (!qt.needsParam && (args.length != 2)) {
				return usage();
			}
			
			if (qt.needsParam) {
				return new QueryData(qt, args[2]);
			} else {
				return new QueryData(qt, null);
			}
		} else {
			return usage();
		}
	}

	/**
	 * Command-line Chinook utility
	 * 
	 * @param args command-line arguments
	 * @throws ClassNotFoundException cannot find JDBC driver
	 * @throws SQLException SQL gone bad
	 */
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		// validates the inputs, exits if bad
		final QueryData qd = validateInputs(args);
		if (qd == null) {
			System.exit(1);
		}
		
		// makes a connection to the database
		try (final Connection connection = DriverManager.getConnection(sqliteConnection(args[0]), roConfig.toProperties())) {
			if (qd.queryType == QueryType.CUSTOMER_BY_COUNTRY) {
				// TODO: Replace with your code using...
				// - Database via `connection`
				// - Country via `qd.queryParam`
				System.out.printf(
					"Your result to query #%d given: %s%n",
					qd.queryType.ordinal()+1,
					qd.queryParam
				);
			} else if (qd.queryType == QueryType.ALL_EMPLOYEES) {
				// TODO: Replace with your code using...
				// - Database via `connection`
				System.out.printf(
					"Your result to query #%d%n",
					qd.queryType.ordinal()+1
				);
			} else if (qd.queryType == QueryType.CUSTOMERS_BY_EMPLOYEE_ID) {
				// TODO: Replace with your code using...
				// - Database via `connection`
				// - Employee id as a string via `qd.queryParam`
				System.out.printf(
					"Your result to query #%d given: %d%n",
					qd.queryType.ordinal()+1,
					Integer.parseInt(qd.queryParam)
				);
			} else if (qd.queryType == QueryType.ALL_CUSTOMERS) {
				// TODO: Replace with your code using...
				// - Database via `connection`
				System.out.printf(
					"Your result to query #%d%n",
					qd.queryType.ordinal()+1
				);
			} else if (qd.queryType == QueryType.INVOICES_BY_CUSTOMER_ID) {
				// TODO: Replace with your code using...
				// - Database via `connection`
				// - Customer id as a string via `qd.queryParam`
				System.out.printf(
					"Your result to query #%d given: %d%n",
					qd.queryType.ordinal()+1,
					Integer.parseInt(qd.queryParam)
				);
			}
		}
	}
}
